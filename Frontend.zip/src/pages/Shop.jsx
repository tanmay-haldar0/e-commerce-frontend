import React from 'react'

const Shop = () => {
  return (
    <div className='mt-20'>
      Shop
    </div>
  )
}

export default Shop
